var dati = {};
var dati2nd = {};
document.addEventListener("DOMContentLoaded", async () => {
    await fetch('https://api.pexels.com/v1/search?query=colors', {
        headers: {
            "Authorization": "n7QioWhTfsYSWrYzQVBrQSFzZ0y3seIaDHN5HfULknAhonhbSlTe03C7",
        },
    }).then((response) => {
        response.json().then((data) => {
            dati = data;
        })
    }).catch((err) => {
        console.log("errore" + err);
    })

    await fetch('https://api.pexels.com/v1/search?query=sun', {
        headers: {
            "Authorization": "n7QioWhTfsYSWrYzQVBrQSFzZ0y3seIaDHN5HfULknAhonhbSlTe03C7",
        },
    }).then((response) => {
        response.json().then((data) => {
            dati2nd = data;
        })
    }).catch((err) => {
        console.log("errore" + err);
    })




    //carousel

    var imgs = document.getElementsByClassName("imgsCarousel");
    imgs[0].src = dati.photos[4].src.medium
    imgs[1].src = dati.photos[5].src.medium
    imgs[2].src = dati.photos[2].src.medium
    for (let img of imgs) {
        img.style.width = "100%"
        img.style.height = "300px"
        img.style.objectFit = "contain"
    }

})

function loadImages() {
    let riga = document.getElementById("riga");
    riga.innerHTML = ""

    dati.photos.forEach((item, i) => {
        let divCol = document.createElement("div");
        divCol.className = "col-md-4";
        divCol.id = "card_" + i;

        let divCard = document.createElement("div");
        divCard.className = "card mb-4 shadow-sm";

        let img = document.createElement("img");
        img.src = item.src.tiny;
        img.id = "img_" + i;

        let cardBody = document.createElement("div");
        cardBody.className = "card-body";

        let dflex = document.createElement("div");
        dflex.className = "d-flex justify-content-between align-items-center";

        let btns = document.createElement("div");
        btns.className = "btn-group";


        let btn1 = document.createElement("button");
        btn1.className = "tn btn-sm btn-outline-secondary";
        btn1.innerText = "View"
        btn1.style.border = "solid 1px red";

        let btn2 = document.createElement("button");
        btn2.innerText = "Nascondi"
        btn2.onclick = () => {
            document.getElementById("card_" + i).style.display = "none";
        }
        btn2.className = "tn btn-sm btn-outline-secondary";
        btn2.style.border = "solid 1px red";

        let p = document.createElement("p");
        p.className = "card-text";
        p.innerText = "This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer."

        let small = document.createElement("small");
        small.className = "text-muted";
        small.innerText = item.id;


        btns.append(btn1, btn2);
        dflex.appendChild(btns);
        dflex.appendChild(small);
        cardBody.appendChild(img);
        cardBody.appendChild(p);
        cardBody.appendChild(dflex);
        divCard.appendChild(cardBody);
        divCol.appendChild(divCard);
        riga.appendChild(divCol);
    })
}
function load2ndImages() {
    let riga = document.getElementById("riga");
    riga.innerHTML = ""

    dati2nd.photos.forEach((item, i) => {
        let divCol = document.createElement("div");
        divCol.className = "col-md-4";
        divCol.id = "card_" + i;

        let divCard = document.createElement("div");
        divCard.className = "card mb-4 shadow-sm";

        let img = document.createElement("img");
        img.src = item.src.tiny;

        let cardBody = document.createElement("div");
        cardBody.className = "card-body";

        let dflex = document.createElement("div");
        dflex.className = "d-flex justify-content-between align-items-center";

        let btns = document.createElement("div");
        btns.className = "btn-group";


        let btn1 = document.createElement("button");
        btn1.className = "tn btn-sm btn-outline-secondary";
        btn1.innerText = "View"
        btn1.style.border = "solid 1px red";

        let btn2 = document.createElement("button");
        btn2.innerText = "Nascondi"
        btn2.onclick = () => {
            document.getElementById("card_" + i).style.display = "none";
        }
        btn2.className = "tn btn-sm btn-outline-secondary";
        btn2.style.border = "solid 1px red";

        let p = document.createElement("p");
        p.className = "card-text";
        p.innerText = "This is a wider card with supporting text below as a natural lead-in to additional content. This content is a little bit longer."

        let small = document.createElement("small");
        small.className = "text-muted";
        small.innerText = item.id;

        btns.append(btn1, btn2);
        dflex.appendChild(btns);
        dflex.appendChild(small);
        cardBody.appendChild(img);
        cardBody.appendChild(p);
        cardBody.appendChild(dflex);
        divCard.appendChild(cardBody);
        divCol.appendChild(divCard);
        riga.appendChild(divCol);

    })
}


//RICHIAMARE API DAL VALORE INSERITO *non mostra a video nessuna immagine*
document.getElementById("cerca").addEventListener("click", async () => {
    let dati = {};
    let value = document.getElementById("inserisciParola").value;
    await new Promise(function (resolve, myReject) {
        fetch("https://api.pexels.com/v1/search?query=" + value, {
            headers: {
                "Authorization": "n7QioWhTfsYSWrYzQVBrQSFzZ0y3seIaDHN5HfULknAhonhbSlTe03C7",
            },
        }).then((response) => {
            response.json().then(async (data) => {
                dati = await data;
                resolve();
            })
        }).catch((err) => {
            console.log("errore : " + err);
        })
    });
})


function carosello() {
    let carosello = document.getElementById("carouselExample");
    if (carosello.classList.contains("d-none") === false) {
        document.getElementById("mostraCarosello").innerText = "Mostra Carosello";
        carosello.classList.add("d-none");
    } else {
        carosello.classList.remove("d-none");
        document.getElementById("mostraCarosello").innerText = "Nascondi Carosello";
    }
}
function removeX() {
    let riga = document.getElementById("riga");
    riga.style.removeProperty("visibility");
}



